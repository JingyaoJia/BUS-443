from django.shortcuts import render
from django.shortcuts import redirect, get_object_or_404
from .models import Student, Course, Enrollment
from django.contrib.auth import authenticate

def home(request):
    if not request.user.is_authenticated:
        return redirect('login')
    students = Student.objects.all()
    courses = Course.objects.all()
    info = {'nStudent': len(students), 'nCourse': len(courses) }
    return render(request, 'v1/home.html', {'info': info})

def student_list( request, ind='1'):
    if not request.user.is_authenticated:
        return redirect('login')
    ind = int(ind)
    students = Student.objects.all()
    students = students[ind*10-10:ind*10]
    return render(request, 'v1/students.html', {'students': students})

def course_list( request, ind='1' ):
    if not request.user.is_authenticated:
        return redirect('login')
    courses = Course.objects.all()
    ind = int(ind)
    courses = courses[ind*10-10:ind*10]
    return render(request, 'v1/courses.html', {'courses': courses})

def enrollment( request, sid='1001') :
    if not request.user.is_authenticated:
        return redirect('login')
    enrollSelected = Enrollment.objects.filter( sid=sid)  
    cSelected = [ er.cid for er in enrollSelected ]
    if request.method == 'POST':
        # enroll for student of sid
        if len(request.POST.getlist('selectedCourse')) + len(cSelected) > 3:
            return render(request, 'v1/Enrollment-error.html', {'sid': sid} )
        for cid in request.POST.getlist('selectedCourse'):
            st = Student.objects.get(sid=sid)
            cs = Course.objects.get(cid = cid)
            p = Enrollment(cid=cs, sid=st)
            p.save()

    enrollSelected = Enrollment.objects.filter( sid=sid)  
    cSelected = [ er.cid for er in enrollSelected ]
    css = [cs.cid for cs in cSelected] 
    cNotSelected = Course.objects.exclude( cid__in = css )
    students = Student.objects.all()
    pickedSid = sid
    studentId = []
    for st in students:
        if st.sid != sid:
            studentId.append(st.sid)
    return render(request, 'v1/Enrollment.html', {'cSelected': cSelected, 'cNotSelected': cNotSelected, 'students': studentId, 'pickedSid': pickedSid})
