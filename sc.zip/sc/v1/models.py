from django.db import models

# Create your models here.
class Student(models.Model):
    sid = models.CharField(primary_key=True, max_length=20)
    firstName = models.CharField(max_length=100)
    lastName = models.CharField(max_length=100)
    major = models.CharField(max_length=100)
    year = models.CharField(max_length=100)
    GPA = models.FloatField()

class Course(models.Model):
    cid = models.CharField(primary_key=True, max_length=20)
    cTitle = models.CharField(max_length=100)
    cName = models.CharField(max_length=100)
    cSectionCode = models.IntegerField()
    cDepartment = models.CharField(max_length=100)
    instructor = models.CharField(max_length=100)

class Enrollment(models.Model):
    sid = models.ForeignKey(Student, on_delete=models.CASCADE)
    cid = models.ForeignKey(Course, on_delete=models.CASCADE)
