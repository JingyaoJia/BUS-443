from django.apps import AppConfig


class V1Config(AppConfig):
    name = 'v1'
