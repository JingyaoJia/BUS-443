from django.urls import path,re_path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
        path('login/', auth_views.LoginView.as_view(template_name='v1/login.html'), name='login' ),
        #re_path(r'^login/$', views.login, name='login'),
        re_path(r'^home/$', views.home, name='home'),
        re_path(r'^$', views.home, name='home'),
        re_path(r'^students/$', views.student_list, name='students'),
        re_path(r'^courses/$', views.course_list, name='courses'),
        re_path(r'^courses/(?P<ind>[0-9]+)$', views.course_list, name='courses'),
        re_path(r'^students/(?P<ind>[0-9]+)$', views.student_list, name='students'),
        re_path(r'^enrollment/$', views.enrollment, name='enrollment'),
        re_path(r'^enrollment/(?P<sid>[0-9]+)$', views.enrollment, name='enrollment'),
        #re_path(r'^courses/$', views.course_list, name='courses'),
         ]


